import { Component, OnInit } from "@angular/core";
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import { MatError } from "@angular/material";
import { takeUntil } from "rxjs/operators";
import { Subject } from "rxjs";
import * as $ from "jquery";
import { Router, RouterLink } from "@angular/router";

import * as _swal from "sweetalert";
import { SweetAlert } from "sweetalert/typings/core";
const swal: SweetAlert = _swal as any;

@Component({
    selector: "app-contact",
    templateUrl: "./contact-us.component.html",
    styleUrls: ["./contact-us.component.scss"]
})
export class ContactUsComponent implements OnInit {
    form: FormGroup;
    formErrors: any;
    private _unsubscribeAll: Subject<any>;
    constructor(private _formBuilder: FormBuilder, private router: Router) {
        this.openMenu();
        this.formErrors = {
            name: {},
            email: {},
            topic: {},
            message: {}
        };
        this._unsubscribeAll = new Subject();
    }

    ngOnInit() {
        this.form = this._formBuilder.group({
            name: ["", Validators.required],
            email: ["", [Validators.required, Validators.email]],
            topic: ["", Validators.required],
            message: ["", Validators.required]
        });
        this.form.valueChanges
            .pipe(takeUntil(this._unsubscribeAll))
            .subscribe(() => {
                this.onFormValuesChanged();
            });
    }

    onFormValuesChanged(): void {
        for (const field in this.formErrors) {
            if (!this.formErrors.hasOwnProperty(field)) {
                continue;
            }
            // Clear previous errors
            this.formErrors[field] = {};
            // Get the control
            const control = this.form.get(field);
            if (control && control.dirty && !control.valid) {
                this.formErrors[field] = control.errors;
            }
        }
    }

    onSubmit() {
        console.log("Name: " + this.form.get("name").value);
        let name = this.form.get("name").value;
        let email = this.form.get("email").value;
        let topic = this.form.get("topic").value;
        let message = this.form.get("message").value;
        if (name && email && topic && message) {
            swal(
                "Great!",
                "Your message has been sent successfully!",
                "success"
            );
            // window.alert("You message has been submited successfully...!");
            // return;
            this.router.navigate(["/"]);
        } else {
            // let str = 'Some fields are missing';
            // window.alert(str);
            swal("Alert!", "Some fields are missing!", "warning");
        }
    }

    openMenu() {
        $("body").removeClass("noScroll");
        if ($(".collapse").hasClass("collapse-active")) {
            $(".collapse").removeClass("collapse-active");
        } else {
            $(".collapse").addClass("collapse-active");
        }
    }
}
