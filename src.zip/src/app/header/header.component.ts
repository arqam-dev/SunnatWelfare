import { Component, OnInit } from "@angular/core";

@Component({
    selector: "app-header",
    templateUrl: "./header.component.html",
    styleUrls: ["./header.component.css"]
})
export class HeaderComponent implements OnInit {
    public toggle: boolean = true;
    constructor() {}

    ngOnInit() {}
    toggleNav() {
        // alert("Alert");
        console.log("this.toggle: " + this.toggle);
        this.toggle = !this.toggle;
        console.log("not this.toggle: " + this.toggle);
    }
}
