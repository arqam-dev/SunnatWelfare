import { Component } from '@angular/core';
import * as $ from 'jquery';


@Component({
  selector: 'app-help',
  templateUrl: './faq.component.html',
  styleUrls: ['./faq.component.scss']
})
export class FaqComponent {

    faqsFiltered = [
        {
            'question': 'Can we deliver the food directly instead of transfering the cash?',
            'answer': 'Yes, You can even meet the people who are receiving it.'
        },
        {
            'question': 'Can we give something to a specific family?',
            'answer': 'Yes, you can give to the family of your own choice.'
        },
        {
            'question': 'Is there any limit of minimum amount to transfer?',
            'answer': 'No, You can give as much as possible.'
        },
        {
            'question': 'In which cities of Pakistan do you offer this facility?',
            'answer': 'We are currently offering this only in lahore.'
        },
        {
            'question': 'Can we donate outside Pakistan?',
            'answer': 'If you are located outside Pakistan, You can only transfer the money to the provided bank account.'
        },
        {
            'question': 'Can we help the people who are unfit medically ?',
            'answer': 'Yes, but you can only give money to them. They will buy medicines themselves. This is actually to avoid any type of mishap.'
        },
        {
            'question': 'Do you provide any job facility?',
            'answer': 'Yes, We have a proper plan to give jobs to the needy through different ways.'
        },
        {
            'question': 'Do you offer these facilities only once for a family?',
            'answer': 'No, We will provide the facilities as long as possible or until you become capable of living on your own earning'
        },
        {
            'question': 'Do you offer loan facility?',
            'answer': 'No, we are not offering any type of loan. Although we provide money to reduce the loan burden of the people.'
        },
        {
            'question': 'Is there any other way to transfer the money?',
            'answer': 'Yes, you can transfer money through cash, easy paisa, etc.'
        },
        {
            'question': 'Can we provide money for the special education?',
            'answer': 'Yes, definitely.'
        },
        {
            'question': 'Do you have any social media group?',
            'answer': 'Yes, we have whatsapp group on given number. You can also join us on facebook, linkedin, etc.'
        },
       {
            'question': 'Do you offer the same facilities in Ramadan?',
            'answer': 'No, we offer ramadaz package with the current package to everyone.'
        },
        {
            'question': 'Will you update us regarding serving to the needy?',
            'answer': 'Yes, we will update you on 10th of every month through email and text message. You will also be updated through our social media groups. We will kepp you updated through all social media links.'
        }
        ];

    constructor() {
        this.openMenu();
    }


    openMenu(){
        $('body').removeClass('noScroll');
        if ($('.collapse').hasClass('collapse-active')) {
            $('.collapse').removeClass('collapse-active');
        }
        else {
            $('.collapse').addClass('collapse-active');
        }
    }

}
